# githubgql
Python library for GraphQL API actions on Github

Packaged using tutorial on
[packaging.python.org](https://packaging.python.org/tutorials/packaging-projects/).
Uses [gh-action-pypi-publish](https://github.com/actions-automation/githubgql)
for automatic publishing.
